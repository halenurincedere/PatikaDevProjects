{
  "ConnectionStrings": {
    "PostgreSqlConnection": "Host=localhost;Port=5432;Database=PatikaCodeFirstDb2;Username=postgres;Password=19385"
  }
}
